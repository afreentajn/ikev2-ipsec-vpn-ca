# Cryptographic Design and Analysis of Secure Site-to-Site Communication Using IKEv2 and IPsec

MACS902 Modern Cryptography – Assessment 2, Applied Cryptography Project
University of Wollongong in Dubai · Group GID_09 · Lecturer: Dr Manoj Kumar
Members: Suraj Sekar, Afreen Nissar, Saniya Salim

## Overview

Two university campuses, Dubai and Australia, communicate across the internet. Each campus gateway router protects the traffic between the campuses with IKEv2 and IPsec. Authentication between the gateways starts with a pre-shared key and is then moved to certificates issued by an offline certificate authority (CA) that the group built in Python on the OpenSSL-backed `cryptography` library.

## Contents

| File | Description |
| --- | --- |
| `ikev2_gateway_ca.py` | Offline certificate authority built in Python on the `cryptography` library (OpenSSL backend). Issues ECDSA P-384 certificates to the two gateways. |
| `Configs/UOWD-DUBAI_psk.txt` | UOWD-DUBAI configuration with pre-shared-key authentication |
| `Configs/UOWD-DUBAI_cert.txt` | UOWD-DUBAI configuration with certificate authentication |
| `Configs/UOWD-AUSTRALIA_psk.txt` | UOWD-AUSTRALIA configuration with pre-shared-key authentication |
| `Configs/UOWD-AUSTRALIA_cert.txt` | UOWD-AUSTRALIA configuration with certificate authentication |

## Topology and addressing

![Topology](topology.png)

| Device | Interface | Address | Purpose |
| --- | --- | --- | --- |
| UOWD-DUBAI | Gi0/0 | 203.0.113.1/30 | Link to the internet |
| UOWD-DUBAI | Loopback1–4 | 10.1.1.1/24 – 10.1.4.1/24 | Admissions and Registration, Human Resources, Lecturers, IT Staff |
| UOWD-DUBAI | Tunnel0 | 172.16.0.1/30 | IPsec tunnel to Australia |
| UOWD-AUSTRALIA | Gi0/0 | 198.51.100.2/30 | Link to the internet |
| UOWD-AUSTRALIA | Loopback1–4 | 10.2.1.1/24 – 10.2.4.1/24 | Web and Student Portal, Application Servers, Database Servers, Management |
| UOWD-AUSTRALIA | Tunnel0 | 172.16.0.2/30 | IPsec tunnel to Dubai |

Traffic between the campuses (10.1.0.0/16 and 10.2.0.0/16) is routed only through Tunnel0, so it is always encrypted.

## Cryptography used

| Function | Algorithm |
| --- | --- |
| Key exchange | ECDH over P-384 (DH group 20), with perfect forward secrecy |
| Key derivation | HMAC-SHA-384 |
| Encryption and integrity | AES-256-GCM |
| Authentication | Pre-shared key (baseline), then ECDSA P-384 certificates |
| Certificate signatures | ECDSA with SHA-384 |

## Router configurations

Each configuration has the same structure. Only the addresses, names and authentication method differ.

### Phase 1 – IKE SA (protects the negotiation between the gateways)

| Configuration block | What it does |
| --- | --- |
| `crypto ikev2 proposal PROP-AES256GCM` | The algorithms offered for Phase 1: AES-256-GCM encryption, HMAC-SHA-384 PRF, DH group 20. Only this one set is configured, so no weaker set can be negotiated. |
| `crypto ikev2 policy POL-AES256GCM` | Applies the proposal. |
| `crypto ikev2 keyring` (PSK version only) | Holds the pre-shared key for the peer gateway's address. |
| `crypto ikev2 profile` | Defines who the peer is and how each side proves its identity: `pre-share` in the PSK version, `ecdsa-sig` with the trustpoint in the certificate version. |

### Phase 2 – IPsec SA (protects the campus traffic)

| Configuration block | What it does |
| --- | --- |
| `crypto ipsec transform-set TS-AES256GCM esp-gcm 256` | ESP with AES-256-GCM for the campus traffic, in tunnel mode. |
| `crypto ipsec profile` | Combines the transform set, `set pfs group20` (a fresh DH exchange at every rekey) and the IKEv2 profile. |
| `interface Tunnel0` | The tunnel between the gateways (`tunnel mode ipsec ipv4`), protected by the IPsec profile. |
| `ip route 10.x.0.0 255.255.0.0 Tunnel0` | Sends traffic for the other campus into the tunnel. |

### PSK version vs certificate version

| | PSK version (`*_psk.txt`) | Certificate version (`*_cert.txt`) |
| --- | --- | --- |
| Identity proof | One shared secret on both gateways | Each gateway's own private key and certificate |
| Extra blocks | `crypto ikev2 keyring` | `crypto pki trustpoint UOWD-ROOT-CA`, `crypto pki certificate map` |
| Profile authentication | `pre-share` | `ecdsa-sig` |
| Peer identity | Peer's IP address | Certificate subject, checked by the certificate map |

## Certificate authority

The CA (`ikev2_gateway_ca.py`) runs on a separate machine with no network connection to the routers. Requests and certificates are carried between the CA and the routers by hand.

| Operation | What it does | Library functions used |
| --- | --- | --- |
| `init` | Creates the CA key pair (ECDSA P-384) and the self-signed root certificate, signed with SHA-384. Stores the private key encrypted under a passphrase and prints the root certificate's fingerprint. | `ec.generate_private_key`, `CertificateBuilder().sign`, `random_serial_number`, `BestAvailableEncryption` |
| `sign` | Reads a router's certificate signing request (CSR), checks that it is signed by the router's own private key and that the key is ECDSA P-384, then issues the router's certificate signed with SHA-384. | `load_pem_x509_csr`, `is_signature_valid`, `CertificateBuilder().sign` |

Requirements: Python 3, the `cryptography` library, and the OpenSSL command-line tool for verification.

```
python3 ikev2_gateway_ca.py init                  # create the CA
python3 ikev2_gateway_ca.py sign <gateway>.csr    # issue a router certificate
openssl verify -CAfile ca_cert.pem <gateway>.crt  # verify it independently
```

## Moving from PSK to certificates

1. Load the PSK configuration on both gateways and confirm the tunnel works.
2. Run `init` on the CA machine to create the root certificate (`ca_cert.pem`).
3. On each router, create its own key pair: `crypto key generate ec keysize 384 label <hostname>-KEY`.
4. Add the trustpoint and install the root certificate: `crypto pki authenticate UOWD-ROOT-CA` (paste `ca_cert.pem`, compare the fingerprint).
5. Create the router's request: `crypto pki enroll UOWD-ROOT-CA`, and copy the CSR to the CA machine.
6. Run `sign` on the CA, then import the certificate on the router: `crypto pki import UOWD-ROOT-CA certificate`.
7. Apply the certificate version of the IKEv2 profile and confirm the tunnel comes up with ECDSA authentication.

## Notes

- The CA private key (`ca_key.pem`) is not included in this repository.
- The pre-shared key in the configurations is shown as the placeholder `<PRE-SHARED-KEY>`.
- Router clocks must be set to the current date before importing certificates, so the certificates are within their validity period.
